﻿using System;

    class GetGreatNumber
    {
        static void Main()
        {
            Console.WriteLine("Enter two possitive integer numbers:");
            int firstNum = int.Parse(Console.ReadLine());
            int secondNum = int.Parse(Console.ReadLine());
            bool check=true;
            Console.Write("The bigger number is:");
            Console.WriteLine(check==(firstNum<secondNum) ? secondNum:firstNum);
            //Console.WriteLine((int)Math.Max(firstNum,secondNum)); //Other solution
        }
    }
